-- Нужно:
-- автодополнение через blink
-- Документация через LSP saga
-- Подсветка ошибок

vim.lsp.enable("lua")
vim.lsp.enable("python")
vim.lsp.enable("cpp")
vim.lsp.enable("latex")
