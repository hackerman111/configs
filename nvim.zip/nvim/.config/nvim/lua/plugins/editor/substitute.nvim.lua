return {
	"gbprod/substitute.nvim",
}
