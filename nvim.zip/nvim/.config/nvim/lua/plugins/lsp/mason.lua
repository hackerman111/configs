return {
	{
		"mason-org/mason.nvim",
		opts = {},
	},

	{

		"mason-org/mason-lspconfig.nvim",
		opts = {},
		dependencies = {
			{ "mason-org/mason.nvim", opts = {} },
		},
		config = function()
			require("mason-lspconfig").setup({
				ensure_installed = { "clangd", "lua_ls", "ruff" },
			})
		end,
	},
}
