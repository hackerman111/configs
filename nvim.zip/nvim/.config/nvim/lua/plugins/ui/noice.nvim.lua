-- Filename: ~/github/dotfiles-latest/neovim/neobean/lua/plugins/noice.lua
-- ~/github/dotfiles-latest/neovim/neobean/lua/plugins/noice.lua

-- I want to change the default notifications to be less obtrussive (if that's even a word)
-- https://github.com/folke/noice.nvim
return {
	{
		"folke/noice.nvim",
		dependencies = {
			"MunifTanjim/nui.nvim",
			"rcarriga/nvim-notify",
		},
		event = "VeryLazy",
		opts = {
			presets = {
				-- This is the search bar or popup that shows up when you press /
				-- Setting this to false makes it a popup and true the search bar at the bottom
				-- search middle
				bottom_search = false,
			},
			messages = {
				-- NOTE: If you enable messages, then the cmdline is enabled automatically.
				-- This is a current Neovim limitation.
				enabled = true, -- enables the Noice messages UI
				view = "notify", -- default view for messages
				view_error = "notify", -- view for errors
				view_warn = "notify", -- view for warnings
				view_history = "notify", -- view for :messages
				view_search = "notify", -- view for search count messages. Set to `false` to disable
			},
			notify = {
				-- Noice can be used as `vim.notify` so you can route any notification like other messages
				-- Notification messages have their level and other properties set.
				-- event is always "notify" and kind can be any log level as a string
				-- The default routes will forward notifications to nvim-notify
				-- Benefit of using Noice for this is the routing and consistent history view
				enabled = true,
				view = "notify",
			},
			lsp = {
				message = {
					enabled = false,
				},
				progress = {
					enabled = false,
				},
			},
			views = {
				-- This sets the position for the search popup that shows up with / or with :
				cmdline_popup = {
					position = {
						row = "40%",
						col = "50%",
					},
				},
				notify = {
					render = "minimal",
					animation_style = "fade_in_slide_out",
					timeout = 400,
				},
				mini = {
					-- timeout = 5000, -- timeout in milliseconds
					timeout = vim.g.neovim_mode == "skitty" and 2000 or 5000,
					align = "center",
					position = {
						-- Centers messages top to bottom
						row = "95%",
						-- Aligns messages to the far right
						col = "100%",
					},
				},
			},
		},
	},
	require("notify").setup({
		background_colour = "#000000",
	}),
}
