return {
	"stevearc/dressing.nvim",
}
